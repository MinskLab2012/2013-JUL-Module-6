  INSERT INTO t_months
  SELECT sq_month_t_id.NEXTVAL, month_desc, month_num
  FROM (
  SELECT distinct calendar_month_name as month_desc, calendar_month_number as month_num
  FROM cls_t_date)
  ;
  
  COMMIT;