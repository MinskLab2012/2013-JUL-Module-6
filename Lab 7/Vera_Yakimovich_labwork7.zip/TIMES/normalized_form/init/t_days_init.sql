  INSERT INTO t_days
  SELECT sq_days_t_id.NEXTVAL, day_desc, day_num
  FROM (
  SELECT distinct day_name as day_desc, day_number_in_week  as day_num
  FROM cls_t_date)
  ;
  
  COMMIT;