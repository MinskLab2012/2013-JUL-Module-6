MERGE INTO t_years
           USING (SELECT DISTINCT calendar_year, days_in_cal_year
                       FROM cls_t_date) src 
           ON (t_years.year_number = TO_NUMBER(src.calendar_year))
           WHEN NOT MATCHED THEN
           INSERT ( year_number,
                         days_in_year)
           VALUES (calendar_year, days_in_cal_year);
		 
COMMIT;		 