--DROP TABLE cls_t_date CASCADE CONSTRAINTS;

CREATE TABLE cls_t_date (
time_id DATE PRIMARY KEY,
day_name varchar2(15),
day_number_in_week varchar2(1),
day_number_in_month varchar2(2),
day_number_in_year varchar2(3),
calendar_week_number varchar2(2),
week_ending_date DATE,
calendar_month_number varchar2(2),
days_in_cal_month varchar2(2),
end_of_cal_month DATE,
calendar_month_name varchar2(15),
days_in_cal_quarter varchar2(2),
beg_of_cal_quarter DATE,
end_of_cal_quarter DATE,
calendar_quarter_number varchar2(2),
calendar_year varchar2(4),
days_in_cal_year varchar2(3),
beg_of_cal_year DATE,
end_of_cal_year DATE
);