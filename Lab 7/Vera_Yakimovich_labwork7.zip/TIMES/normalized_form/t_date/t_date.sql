--ALTER TABLE t_date
--   DROP CONSTRAINT fk_t_days2t_date;
--ALTER TABLE t_date
--   DROP CONSTRAINT fk_t_months2t_date;
--ALTER TABLE t_date
--   DROP CONSTRAINT fk_t_years2t_date;  
--DROP TABLE t_date CASCADE CONSTRAINTS; 
   
CREATE TABLE t_date (
time_id DATE PRIMARY KEY,
day_id number(1),
day_number_in_month varchar2(2),
day_number_in_year varchar2(3),
calendar_week_number varchar2(2),
week_ending_date DATE,
month_id number (2),
days_in_cal_month varchar2(2),
end_of_cal_month DATE,
days_in_cal_quarter varchar2(2),
beg_of_cal_quarter DATE,
end_of_cal_quarter DATE,
calendar_quarter_number varchar2(2),
year_number number(4),
beg_of_cal_year DATE,
end_of_cal_year DATE,
CONSTRAINT fk_t_days2t_date FOREIGN KEY (day_id) 
        REFERENCES t_days(day_id),
CONSTRAINT fk_t_months2t_date FOREIGN KEY (month_id) 
        REFERENCES t_months(month_id),  
CONSTRAINT fk_t_years2t_date FOREIGN KEY (year_number) 
        REFERENCES t_years(year_number)              
);