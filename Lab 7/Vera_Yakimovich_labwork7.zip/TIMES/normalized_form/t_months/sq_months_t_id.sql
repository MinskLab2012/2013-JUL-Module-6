--drop sequence sq_month_t_id;

create sequence sq_month_t_id;