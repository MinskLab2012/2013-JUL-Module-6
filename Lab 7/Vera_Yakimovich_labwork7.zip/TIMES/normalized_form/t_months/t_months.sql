--DROP TABLE t_months CASCADE CONSTRAINTS;

CREATE TABLE t_months (
month_id number(2) PRIMARY KEY,
month_desc varchar(15),
month_number_in_year number(2)
);