--ALTER TABLE t_years
--   DROP CONSTRAINT cns_days_in_year;
--DROP TABLE t_years CASCADE CONSTRAINTS;

CREATE TABLE t_years (
year_number number (4) PRIMARY KEY,
days_in_year number(3),
CONSTRAINT  cns_days_in_year
                     CHECK (days_in_year IN (364,365,366))
);