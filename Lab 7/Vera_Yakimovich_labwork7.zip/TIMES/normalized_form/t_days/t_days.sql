--DROP TABLE t_days CASCADE CONSTRAINTS;

CREATE TABLE t_days (
day_id number(1) PRIMARY KEY,
day_desc varchar2(12),
day_number_in_week number (1)
);
