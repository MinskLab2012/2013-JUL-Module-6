--drop sequence sq_days_t_id;

create sequence sq_days_t_id;