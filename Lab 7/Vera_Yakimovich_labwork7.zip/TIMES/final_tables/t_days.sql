--DROP TABLE t_days;
CREATE TABLE t_days as
SELECT 
  TRUNC( sd + rn ) time_id,
  TO_CHAR( sd + rn, 'fmDay' ) day_name,
  TO_CHAR( CASE WHEN TO_CHAR(sd + rn, 'D') = '1' OR TO_CHAR(sd + rn, 'D') = '7'
                            THEN 'N'
                   ELSE 'Y'
                   END ) day_workday_indicator, 
  TO_CHAR( sd + rn, 'D' ) day_number_in_week,
  TO_CHAR( sd + rn, 'DD' ) day_number_in_month,
  TO_CHAR( sd + rn, 'DDD' ) day_number_in_year
FROM
  ( 
    SELECT 
      TO_DATE( '12/31/2012', 'MM/DD/YYYY' ) sd,
      rownum rn
    FROM dual
      CONNECT BY level <= 366
  );
 --select * from t_days;